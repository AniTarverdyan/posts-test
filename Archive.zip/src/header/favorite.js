const Favorite = () => {
    return <div>
        Favorite
    </div>
}

export default Favorite;