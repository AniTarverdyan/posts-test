const Note = () => {
    return (
        <div>
            notes
        </div>
    )
}

export default Note;